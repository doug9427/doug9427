Foster Care - Final Project
Group Project Produced by

Douglas Bell

Rushelle Phillips

Rachel Korman

Students of Entity Academy & Woz-U
